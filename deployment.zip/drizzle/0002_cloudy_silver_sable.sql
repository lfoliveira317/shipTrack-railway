ALTER TABLE `attachments` ADD `s3Key` varchar(500);--> statement-breakpoint
ALTER TABLE `attachments` ADD `s3Url` varchar(1000);